<?php

	// clears the user's session
	
	session_start();
	session_destroy();
?><response/>